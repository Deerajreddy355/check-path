package com.npw.app.product.dashboard.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.npw.app.product.dashboard.entity.Item;

public interface ItemRepository extends CrudRepository<Item, Long> {

	@Query("SELECT p FROM Item p where p.sku = :sku")
	public Item findBySku(@Param(value = "sku") String sku);

}