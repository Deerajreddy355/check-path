package com.npw.app.product.dashboard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.npw.app.product.dashboard.dao.OrderRepository;
import com.npw.app.product.dashboard.entity.DBorder;

@Service
public class OrderService {

	@Autowired
	OrderRepository orderRepository;

	public boolean addOrder(DBorder order) {
		orderRepository.save(order);
		return true;
	}

	public DBorder getOrder(Long orderId) {
		return orderRepository.findById(orderId).get();
	}

	public boolean updateOrder(DBorder order) {
		DBorder o = orderRepository.findById(order.getId()).get();
		o.setNewShipDate(order.getNewShipDate());
		String date = o.getEstimatedTime();
		date.replace(date.substring(0,date.indexOf("-")), order.getNewShipDate().toString());
		o.setEstimatedTime(date);
		orderRepository.save(o);
		return true;
	}

	public boolean cancelOrder(Long orderId) {
		DBorder o = getOrder(orderId);
		orderRepository.delete(o);
		return true;
	}

}
