package com.npw.app.product.dashboard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.npw.app.product.dashboard.dao.CustomerRepository;
import com.npw.app.product.dashboard.entity.Customer;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	public boolean addCustomer(Customer customer) {
		customerRepository.save(customer);
		return true;
	}

	public Customer getItem(Long custId) {
		return customerRepository.findById(custId).get();
	}

}
