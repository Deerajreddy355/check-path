package com.npw.app.product.dashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.npw.app.product.dashboard.entity.Item;
import com.npw.app.product.dashboard.service.ItemService;

@RestController
@RequestMapping(value = "/catalog/sku")
public class CatalogController {

	@Autowired
	ItemService itemService;

	@PostMapping(consumes = "application/json")
	public ResponseEntity addItem(@RequestBody Item item) {
		boolean response = itemService.addItem(item);
		if (response) {
			return new ResponseEntity(HttpStatus.CREATED);
		} else {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping
	public ResponseEntity<Item> getItemById(Long orderId) {
		Item order = itemService.getItem(orderId);
		return new ResponseEntity(order, HttpStatus.OK);
	}

	@GetMapping(value="/sku/{skuId}")
	public ResponseEntity<Item> getItemById(@PathVariable("skuId") String skuId) {
		Item order = itemService.getItemBySky(skuId);
		return new ResponseEntity(order, HttpStatus.OK);
	}

}
