package com.npw.app.product.dashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.npw.app.product.dashboard.entity.Customer;
import com.npw.app.product.dashboard.entity.Item;
import com.npw.app.product.dashboard.entity.DBorder;
import com.npw.app.product.dashboard.service.CustomerService;
import com.npw.app.product.dashboard.service.ItemService;
import com.npw.app.product.dashboard.service.OrderService;

@RestController
@RequestMapping
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	ItemService itemService;

	@PostMapping(value="/order", consumes = "application/json")
	public ResponseEntity addOrder(@RequestBody DBorder order) {
		boolean response = orderService.addOrder(order);
		if (response) {
			return new ResponseEntity(HttpStatus.CREATED);
		} else {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(value = "/orderactions/acceptShipDate", consumes = "application/json")
	public ResponseEntity acceptShipDate(@RequestBody DBorder order) {
		boolean response = orderService.updateOrder(order);
		if (response) {
			return new ResponseEntity(HttpStatus.CREATED);
		} else {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(value = "/orderactions/cancelItem", consumes = "application/json")
	public ResponseEntity cancelItem(@RequestBody Item item, @RequestParam("orderId") Long orderId) {
		boolean response = itemService.cancelItem(item,orderId);
		if (response) {
			return new ResponseEntity(HttpStatus.CREATED);
		} else {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(value = "/orderactions/cancelOrder", consumes = "application/json")
	public ResponseEntity cancelOrder(@RequestParam("orderId") Long orderId) {
		boolean response = orderService.cancelOrder(orderId);
		if (response) {
			return new ResponseEntity(HttpStatus.CREATED);
		} else {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	}
	

	@GetMapping(value="/order/{orderId}")
	public ResponseEntity<DBorder> getOrder(@PathVariable("orderId") Long orderId) {
		DBorder order = orderService.getOrder(orderId);
		return new ResponseEntity(order, HttpStatus.OK);
	}
	
	@PostMapping(value="/customer",consumes = "application/json")
	public ResponseEntity addCustomer(@RequestBody Customer customer) {
		boolean response = customerService.addCustomer(customer);
		if (response) {
			return new ResponseEntity(HttpStatus.CREATED);
		} else {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
	}
	
	
}
