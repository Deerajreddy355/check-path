package com.npw.app.product.dashboard.dao;

import org.springframework.data.repository.CrudRepository;

import com.npw.app.product.dashboard.entity.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Long> {
	
}