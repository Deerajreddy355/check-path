package com.npw.app.product.dashboard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.npw.app.product.dashboard.dao.ItemRepository;
import com.npw.app.product.dashboard.dao.OrderRepository;
import com.npw.app.product.dashboard.entity.Item;
import com.npw.app.product.dashboard.entity.DBorder;

@Service
public class ItemService {
	@Autowired
	ItemRepository itemRepository;
	
	
	@Autowired
	OrderRepository orderRepository;

	public boolean addItem(Item item) {
		try {
			itemRepository.save(item);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public Item getItem(Long itemId) {
		return itemRepository.findById(itemId).get();
	}
	
	public Item getItemBySky(String sku) {
		return itemRepository.findBySku(sku);
	}

	public boolean cancelItem(Item item, Long orderId) {
		DBorder order=orderRepository.findById(orderId).get();
		order.getItems().remove(item);
		orderRepository.save(order);
		return true;
	}

}
